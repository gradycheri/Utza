class GMStorage {
    constructor(key = 'gm-storage', limit = 18) {
        this.key = key;
        this.arrayIdGameStorage = localStorage.getItem(this.key) ? JSON.parse(localStorage.getItem(this.key)) : [];
        this.limit = limit;
    }


    save = () => {
        return localStorage.setItem(this.key, JSON.stringify(this.arrayIdGameStorage))
    }

    get = () => {
        return localStorage.getItem(this.key) || null;
    }

    addGame = (id_game) => {
        if (!this.checkGameExist(id_game)) {
            this.arrayIdGameStorage.push(id_game)
            this.arrayIdGameStorage = this.arrayIdGameStorage.slice(-this.limit);
            this.save();
        }
    }

    checkGameExist = (id_game) => {
        if (this.arrayIdGameStorage.includes(id_game)) return true;
        return false;
    }

    checkGameObjectExist = (id_game) => {
        let favorites = JSON.parse(localStorage.getItem(this.key) || '[]');
        const index = favorites.findIndex(v => v.id === id_game);
        return index !== -1
    }

    removeGame = (id_game) => {
        if (this.checkGameExist(id_game)) {
            const index = this.arrayIdGameStorage.findIndex(v => v === id_game);
            if (index !== -1) {
                this.arrayIdGameStorage.splice(index, 1);
                this.save(); // Don't forget to save after removal
                return true;
            }
        }
        return false;
    }

    addGameObject = (gameObject) => {
        let favorites = JSON.parse(localStorage.getItem(this.key) || '[]');

        const exists = favorites.some(game => game.id === gameObject.id);
        const index = favorites.findIndex(game => game.id === gameObject.id);
        if (!exists) {
            favorites.push(gameObject);
            localStorage.setItem(this.key, JSON.stringify(favorites));

        } else {
            favorites[index] = {
                ...favorites[index],
                ...gameObject
            };
            localStorage.setItem(this.key, JSON.stringify(favorites));

        }

        if (typeof loadFavoriteGames === 'function') {
            loadFavoriteGames();
        }

        return true;
    }

    removeGameObject = (gameId) => {
        let items = JSON.parse(localStorage.getItem(this.key) || '[]');

        const originalLength = items.length;
        items = items.filter(game => game.id !== gameId);

        localStorage.setItem(this.key, JSON.stringify(items));

        if (typeof loadFavoriteGames === 'function') {
            loadFavoriteGames();
        }

        return items.length < originalLength;
    }

    clear = () => {
        localStorage.removeItem(this.key)
    }

}