
document.addEventListener('DOMContentLoaded', function () {
    var shellpull = $('span#cookie-pull');
    shellpull.on('click', function (e) {
        $('.cookie-menu-header-mobile').css('right', '0');
        $("body").css({
            overflow: "hidden",
            height: "100svh"
        });
    });
    $('#back_to_top').fadeOut();
    $(window).scroll(function () {
        if ($(this).scrollTop() > 200) {//Trả về vị trí thanh cuộn dọc
            $('#back_to_top').fadeIn();//mờ dần phần tử 
        } else {
            $('#back_to_top').fadeOut();
        }
    });
    $("#back_to_top").click(function () {
        event.preventDefault();
        $("html, body").animate({ scrollTop: 0 }, 500);
    });
    $("#expand").on('click', function () {
        $("#iframe_game_play").addClass("force_full_screen");
        $("#_exit_full_screen").addClass("active");
        requestFullScreen(document.body);
    });
    $("#_exit_full_screen").on('click', cancelFullScreen);
    function requestFullScreen(element) {
        $("body").css({ "overflow-y": "hidden" });
        var requestMethod = element.requestFullScreen || element.webkitRequestFullScreen || element.mozRequestFullScreen || element.msRequestFullScreen;
        if (requestMethod) {
            requestMethod.call(element);
        } else if (typeof window.ActiveXObject !== "undefined") {
            var wscript = new ActiveXObject("WScript.Shell");
            if (wscript !== null) {
                wscript.SendKeys("{F11}");
            }
        }
    }

    function cancelFullScreen() {
        $("#_exit_full_screen").removeClass("active");
        $('body').css({ "overflow-y": "scroll" });
        $("#iframe_game_play").removeClass("force_full_screen");
        $(".game-play").removeClass('theater__mode')
        $('body').attr('style', "")
        var requestMethod = document.cancelFullScreen || document.webkitCancelFullScreen || document.mozCancelFullScreen || document.exitFullScreenBtn;
        if (requestMethod) {
            requestMethod.call(document);
        } else if (typeof window.ActiveXObject !== "undefined") {
            var wscript = new ActiveXObject("WScript.Shell");
            if (wscript !== null) {
                wscript.SendKeys("{F11}");
            }
        }
    }

    if (document.addEventListener) {
        document.addEventListener('webkitfullscreenchange', exitHandler, false);
        document.addEventListener('mozfullscreenchange', exitHandler, false);
        document.addEventListener('fullscreenchange', exitHandler, false);
        document.addEventListener('MSFullscreenChange', exitHandler, false);
    }

    function exitHandler() {
        if (document.webkitIsFullScreen === false
            || document.mozFullScreen === false
            || document.msFullscreenElement === false) {
            cancelFullScreen();
        }
    }


});

function cookieunset() {
    $("body").css({
        overflow: "unset",
        height: "unset"
    });
    $('.cookie-menu-header-mobile').css('right', '-100%');
}


function theaterMode() {
    if ($(".game-play").hasClass("theater__mode")) {
        $(".game-play").removeClass('theater__mode')
        $('body').attr('style', "")
    } else {
        $(".game-play").addClass('theater__mode')
        $('body').attr('style', "overflow:hidden;")
    }
}


// Game's action

const gmFavorite = new GMStorage(location.hostname + 'gm-favorite');
const gmHistory = new GMStorage(location.hostname + 'gm-history');
const gmLike = new GMStorage(location.hostname + 'gm-like');
const gmDislike = new GMStorage(location.hostname + 'gm-dislike');
let favorite = false;
let like, dislike;

function loadFavoriteGames() {
    const games = JSON.parse(gmFavorite.get());
    let html = '';
    if (!Array.isArray(games) || games.length == 0) {
        html += `<div class="no-games" style="color: var(--color-secondary);">Add games to your favorites by clicking on the ♡ icon on a game page.
        </div>`;
    } else {
        html += `<div class="favorite_games--container">`;
        const gameHtml = games.map(g =>
            `<div class="cr-item">
            <a href="/${g.slug}">
            <div class="cr-detail">
            <div class="cr-item-content">
            <div class="cr-img">
            <img loading="lazy" src="${g.image}" >
            </div>
            <div class="cr-info">
            <span>${g.name}</span>
            </div>
            </div>
            </div>
            </a>
            </div>`).join("\n");
        html += gameHtml;
        html += `</div>`;
    };



    $("#favourite-content").html(html);
}


jQuery(function ($) {

    loadFavoriteGames();

    if (id_game) {

        let like = gmLike.checkGameExist(id_game);
        let dislike = gmDislike.checkGameExist(id_game);
        // Loading favorite state
        favorite = gmFavorite.checkGameObjectExist(id_game);
        if (favorite) {
            $("#favorite").addClass('active');
        }
        // Loading like & dislike state
        if (like && dislike) {
            gmDislike.removeGame(id_game);
            $("#like").addClass("active");
            $("#dislike").removeClass("active");
        } else if (like && !dislike) {
            $("#like").addClass("active");
            $("#dislike").removeClass("active");
        } else if (!like && dislike) {
            $("#dislike").addClass("active");
            $("#like").removeClass("active");
        }

    }

    $("#like").on("click", function () {
        $.ajax({
            url: '/likegame.ajax',
            method: 'post',
            data: {
                id_game,
                is_like: !like,
                is_dislike: dislike
            },
            success: (resp) => {
                like = !like;
                if (like) {
                    $("#dislike").removeClass("active");
                    $("#like").addClass("active");
                    gmLike.addGame(id_game);
                    gmDislike.removeGame(id_game);
                    dislike = false;
                } else {
                    gmLike.removeGame(id_game);
                    $("#like").removeClass("active");
                }
                $('#like-num').html(resp);
            },
            error: (err) => console.error(err)
        });
    });

    $("#dislike").on("click", function () {
        $.ajax({
            url: '/dislikegame.ajax',
            method: 'post',
            data: {
                id_game,
                is_dislike: !dislike,
                is_like: like
            },
            success: (resp) => {
                dislike = !dislike;
                if (dislike) {
                    $("#dislike").addClass("active");
                    $("#like").removeClass("active");
                    if (like) {
                        $('#like-num').html(Number($('#like-num').html()) > 1 ? Number($('#like-num').html()) - 1 : 0);
                    }
                    gmDislike.addGame(id_game);
                    gmLike.removeGame(id_game);
                    like = false;
                } else {
                    gmDislike.removeGame(id_game);

                    $("#dislike").removeClass("active");
                }
            },
            error: (err) => console.error(err)
        });
    });


    $("#favorite").on("click", function () {
        favorite = !favorite;
        if (favorite) {
            gmFavorite.addGameObject(main_game);
            $("#favorite").addClass('active')
        } else {
            gmFavorite.removeGameObject(main_game.id);
            $("#favorite").removeClass('active');
        }
        loadFavoriteGames();
    })

    $('.share__copy--btn').on('click', function () {
        const $btn = $(this);
        const $input = $btn.siblings('.share__input');

        // Copy input value to clipboard
        $input.select();
        document.execCommand('copy');

        // Toggle copied class for 3 seconds
        $btn.removeClass('copied'); // reset if already active
        void $btn[0].offsetWidth;    // force reflow
        $btn.addClass('copied');

        setTimeout(function () {
            $btn.removeClass('copied');
        }, 3000);
    });

    $('[data-sidebar]').on('click', function () {
        $("body").css({
            overflow: "hidden",
            height: "100svh"
        });
        var type = $(this).data('sidebar');

        // Hide all sidebars first
        $('.sidebar').removeClass('active');

        // Show the chosen sidebar
        $('.sidebar[type="' + type + '"]').addClass('active');

        // Show overlay
        $('.overlay').addClass('active');
    });

    // Close sidebar when clicking close button or overlay
    $('.sidebar__close, .overlay').on('click', function () {
        $("body").css({
            overflow: "unset",
            height: "unset"
        });
        $('.sidebar').removeClass('active');
        $('.overlay').removeClass('active');
    });

    $('#report-form').on('submit', function (e) {
        e.preventDefault(); // prevent default form submission

        const $form = $(this);
        const formData = $form.serialize(); // serialize all input values

        $('#report-result').text('Sending...');

        $.ajax({
            url: $form.attr('action'),
            type: $form.attr('method'),
            data: formData,
            success: function (response) {
                // handle server response (assume JSON or plain text)
                $('#report-result').html(response);
                $form.trigger('reset');
                setTimeout(() => {
                    $('#report-result').html('');
                }, 10000)
            }
        });
    });
});


function paging(p) {
    $(".gif").removeClass("hidden");
    var url = '/paging.ajax';
    $.ajax({
        type: "POST",
        url: url,
        data: {
            page: p,
            keywords: keywords,
            tags_id: tag_id,
            category_id: category_id,
            field_order: field_order,
            order_type: order_type,
            is_hot: is_hot,
            is_new: is_new,
            is_trending: is_trending,
            limit: limit
        },
        success: function (xxxx) {
            if (xxxx !== '') {
                $("#ajax-append").html(xxxx);
            }
        }
    });
}